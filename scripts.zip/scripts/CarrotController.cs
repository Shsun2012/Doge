﻿using UnityEngine;
using System.Collections;

public class CarrotController : MonoBehaviour {

	public float speed;
	public PlayerController player;

	//public GameObject enemyDeathEffect;
	public GameObject impactEffect;
	//public int pointForKill;

	public float rotationSpeed;
	public int damageToGive;
	private Rigidbody2D myrigidbody2D;

	// Use this for initialization
	void Start () {
		player = FindObjectOfType<PlayerController> ();
		myrigidbody2D = GetComponent<Rigidbody2D> ();

		if (player.transform.localScale.x > transform.position.x) {
			speed = -speed;
			//rotationSpeed = -rotationSpeed;
		}

	}

	// Update is called once per frame
	void Update () {
		
		myrigidbody2D.velocity = new Vector2 (speed, GetComponent<Rigidbody2D> ().velocity.y);
		myrigidbody2D.angularVelocity = rotationSpeed;

	}

	void OnTriggerEnter2D(Collider2D other){;
		if (other.tag == "Player") {
			//Instantiate (enemyDeathEffect, other.transform.position, other.transform.rotation);
			//Destroy (other.gameObject);
			//ScoreManager.AddPoints (pointForKill);
			//other.GetComponent<EnemyHealthManager>().giveDamage(damageToGive);
			HealthManager.HurtPlayer(damageToGive);

		}

		Instantiate (impactEffect, transform.position, transform.rotation);
		Destroy (gameObject);
	}
}
