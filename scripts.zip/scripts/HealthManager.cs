﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class HealthManager : MonoBehaviour {

	public int maxPlayerHealth;
	public static int playerHealth;
	//Text text;
	private LevelManager levelManager;
	public bool isDead;
	// Use this for initialization

	public Slider healthBar;


	void Start () {
		//healthBar = GetComponent<Slider> ();
		healthBar = FindObjectOfType<Slider> ();
		playerHealth = maxPlayerHealth;
		levelManager = FindObjectOfType<LevelManager> ();
		isDead = false;
	}
	
	// Update is called once per frame
	void Update () {
		if (playerHealth <= 0 && !isDead) {
			levelManager.RespawnPlayer ();
			isDead = true;
		}
		healthBar.value = playerHealth;
		if (playerHealth > maxPlayerHealth) {
			playerHealth = maxPlayerHealth;
		}
	}

	public static void HurtPlayer(int damageToGive){

		playerHealth -= damageToGive;
	}

	public void FullHealth(){
		playerHealth = maxPlayerHealth;
	}
}
