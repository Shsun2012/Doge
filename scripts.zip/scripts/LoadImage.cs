﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class LoadImage : MonoBehaviour {

	public string characterImageName;
	public Sprite characterSprite;

	public void SetImage(){
		Sprite newSprite = characterSprite;
		Image characterImage = GameObject.Find (characterImageName).GetComponent<Image> ();
		characterImage.sprite = newSprite;
	}

}
