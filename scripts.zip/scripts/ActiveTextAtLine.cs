﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ActiveTextAtLine : MonoBehaviour {

	public TextAsset theText;
	public int startLine;
	public int endLine;
	public TextBoxManager theTextBox;

	public bool requireButtonPress;
	private bool waitForPress;
	public bool destroyWhenActivated;
	public Sprite image1;
	//public Sprite image2;

	// Use this for initialization
	void Start () {
		theTextBox = FindObjectOfType<TextBoxManager> ();

	}
	
	// Update is called once per frame
	void Update () {
		if (waitForPress && Input.GetKeyDown (KeyCode.L)){
			theTextBox.theImage1.sprite = image1;
			//theTextBox.theImage2.sprite = image2;
			theTextBox.ReloadScript (theText);
			theTextBox.currentLine = startLine;
			theTextBox.endAtLine = endLine;
			theTextBox.EnableTextBox ();
			if (destroyWhenActivated) {
				Destroy (gameObject);
			}
		}
	}

	void OnTriggerEnter2D(Collider2D other){

		if (other.name == "Player") {
			
			if (requireButtonPress) {
				waitForPress = true;
				return;
			}
			theTextBox.theImage1.sprite = image1;
			//theTextBox.theImage2.sprite = image2;
			theTextBox.ReloadScript (theText);
			theTextBox.currentLine = startLine;
			theTextBox.endAtLine = endLine;
			theTextBox.EnableTextBox ();

			if (destroyWhenActivated) {
				Destroy (gameObject);
			}
		}
	}

	void onTriggerExit2D(Collider2D other){
		if (other.name == "Player") {
			waitForPress = false;
			Debug.Log ("exit");
		}
	}
}
