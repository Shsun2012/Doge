﻿using UnityEngine;
using System.Collections;

public class ShootPlayerInRange : MonoBehaviour {

	public float playerRange;
	public GameObject carrot;

	public PlayerController player;
	public Transform launchPoint;

	public float waitBetweenShot;
	private float shotcounter;

	// Use this for initialization
	void Start () {
		player = FindObjectOfType<PlayerController> ();
		shotcounter = waitBetweenShot;
	}
	
	// Update is called once per frame
	void Update () {

		shotcounter -= Time.deltaTime;

		if (transform.localScale.x < 0 && player.transform.position.x > transform.position.x && player.transform.position.x < transform.position.x + playerRange && shotcounter <0) {
			Instantiate (carrot, launchPoint.position, launchPoint.rotation);
			shotcounter = waitBetweenShot;
		}
		if (transform.localScale.x > 0 && player.transform.position.x < transform.position.x && player.transform.position.x > transform.position.x - playerRange && shotcounter <0) {
			Instantiate (carrot, launchPoint.position, launchPoint.rotation);
			shotcounter = waitBetweenShot;
		}
	}
}
