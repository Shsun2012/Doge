﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class mainMenu : MonoBehaviour {

	public string startLevel;
	public string levelSelect;


	public void NewGame(){
		//Application.LoadLevel (startLevel);
		SceneManager.LoadScene (startLevel);

	}

	public void LevelSelect(){
		//Application.LoadLevel (levelSelect);
		SceneManager.LoadScene (levelSelect);
	}


	public void QuitGame(){
		Debug.Log ("exit");
		Application.Quit ();
	}

}
