﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {

	public float moveSpeed;
	public float jumpHeight;
	public Transform groundCheck;
	public float groundCheckRadius;
	public LayerMask whatIsGround;

	private bool grounded;
	public bool fire;
	public bool knife;
	private float moveVelocity;

	private bool doubleJumped;
	private Animator anim;

	public Transform firePoint;
	public GameObject fireGun;

	public float shootDelay;
	private float shootDelayCounter;

	public float knockBack;
	public float knockBackCount;
	public float knockBackLength;
	public bool knockFromRight;
	public bool canMove;

	// Use this for initialization
	void Start () {
		anim = GetComponent<Animator> ();
	}

	void FixedUpdate(){
		grounded = Physics2D.OverlapCircle (groundCheck.position, groundCheckRadius, whatIsGround);
	}

	// Update is called once per frame
	void Update () {

		if (!canMove) {
			return;
		}

		if (grounded) {
			doubleJumped = false;
		}

		anim.SetBool ("Grounded", grounded);

		if(Input.GetKeyDown (KeyCode.Space) && grounded)
		{
			Jump ();
		}

		if(Input.GetKeyDown (KeyCode.Space) && !doubleJumped &&!grounded )
		{
			Jump ();
			doubleJumped = true;
		}

		moveVelocity = 0f;

		if(Input.GetKey (KeyCode.RightArrow))
		{
			//GetComponent<Rigidbody2D> ().velocity = new Vector2 (moveSpeed,GetComponent<Rigidbody2D>().velocity.y);
			moveVelocity = moveSpeed;
		}

		if(Input.GetKey (KeyCode.LeftArrow))
		{
			//GetComponent<Rigidbody2D> ().velocity = new Vector2 (-moveSpeed,GetComponent<Rigidbody2D>().velocity.y);
			moveVelocity = -moveSpeed;
		}

		if (knockBackCount <= 0) {
			GetComponent<Rigidbody2D> ().velocity = new Vector2 (moveVelocity, GetComponent<Rigidbody2D> ().velocity.y);
		} else {
			if (knockFromRight) {
				GetComponent<Rigidbody2D> ().velocity = new Vector2 (-knockBack, knockBack);
			} else {
				GetComponent<Rigidbody2D> ().velocity = new Vector2 (knockBack, knockBack);
			}
			knockBackCount -= Time.deltaTime;
		}


		anim.SetFloat ("Speed", Mathf.Abs(GetComponent<Rigidbody2D>().velocity.x));
		if (GetComponent<Rigidbody2D> ().velocity.x > 0) {
			transform.localScale = new Vector3 (1f, 1f, 1f);
		} else if (GetComponent<Rigidbody2D> ().velocity.x < 0) {
			transform.localScale = new Vector3 (-1f, 1f, 1f);
		}
			
		anim.SetBool ("Fire", fire);
		if (Input.GetKeyDown (KeyCode.J)) {
			fire = true;
			Instantiate (fireGun, firePoint.position, firePoint.rotation);
			shootDelayCounter = shootDelay;

		}


		if (Input.GetKey (KeyCode.J)) {
			fire = true;
			shootDelayCounter -= Time.deltaTime;
			if (shootDelayCounter <= 0) {
				shootDelayCounter = shootDelay;
				Instantiate (fireGun, firePoint.position, firePoint.rotation);
			}
		}

		if (Input.GetKeyUp (KeyCode.J)) {
			fire = false;
		}


		if (anim.GetBool ("Knife")) {
			anim.SetBool ("Knife", false);
		}
		if (Input.GetKey (KeyCode.K)) {
			anim.SetBool ("Knife", true);
		}


	}

	public void Jump(){
		GetComponent<Rigidbody2D> ().velocity = new Vector2 (GetComponent<Rigidbody2D>().velocity.x,jumpHeight);
	}

	void OnCollisionEnter2D(Collision2D other){

		if (other.transform.tag == "MovingPlatform") {
			transform.parent = other.transform;
		}
	}

	void OnCollisionExit2D(Collision2D other){

		if (other.transform.tag == "MovingPlatform") {
			transform.parent = null;
		}
	}
}
